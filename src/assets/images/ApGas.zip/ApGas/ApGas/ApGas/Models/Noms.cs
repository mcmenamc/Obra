﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApGas.Models
{
    public class Noms
    {
        public int Key { get; set; }
        public string Value { get; set; }
    }

    
}
