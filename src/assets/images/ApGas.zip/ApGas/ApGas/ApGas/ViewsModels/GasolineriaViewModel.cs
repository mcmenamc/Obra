﻿using ApGas.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Xamarin.Forms;

namespace ApGas.ViewsModels
{
    public class GasolineriaViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged()
        {
            throw new NotImplementedException();
        }

        HttpClient Cliente;
        private const string URIGaso = "https://petrointelligence.com/api/api_precios.html?consulta=nac&estado";


        private int _sinseleccion2;
        public int SinSeleccion2
        {
            get { return _sinseleccion2; }
            set
            {
                _sinseleccion2 = value;
                OnPropertyChanged();
            }
        }

        private int _sinseleccion;
        public int SinSeleccion
        {
            get { return _sinseleccion; }
            set
            {
                _sinseleccion = value;
                OnPropertyChanged();
            }
        }

        private TipoGasolina _seleccionTGas;
        public TipoGasolina SeleccionTGas
        {
            get { return _seleccionTGas; }
            set
            {
                _seleccionTGas = value;
                OnPropertyChanged();
            }
        }

        private Noms _seleccionCiudad;
        public Noms SeleccionCiudad
        {
            get { return _seleccionCiudad; }
            set
            {
                _seleccionCiudad = value;
                OnPropertyChanged();
            }
        }

        public List<TipoGasolina> Tipos { set; get; }

        public List<TipoGasolina> CrearListaTipos()
        {
            var tiposG = new List<TipoGasolina>()
            {
                new TipoGasolina(){Key = 1, Value="Regular"},
                new TipoGasolina(){Key = 2, Value="Premium"},
                new TipoGasolina(){Key = 3, Value="Diésel"}

            };
            return tiposG;
        }

        public List<Noms> Ciudades { set; get; }
        public List<Noms> CrearListaNoms()
        {
            var tiposN = new List<Noms>()
            {
                new Noms(){Key = 1, Value="PUEBLA"},
                new Noms(){Key = 2, Value="VERACRUZ"},
                new Noms(){Key = 3, Value="SONORA"},
                new Noms(){Key = 4, Value="CHIAPAS"},
                new Noms(){Key = 5, Value="YUCATAN"},
                new Noms(){Key = 6, Value="JALISCO"},
                new Noms(){Key = 7, Value="MORELOS"},
                new Noms(){Key = 8, Value="NAYARIT"},
                new Noms(){Key = 9, Value="DURANGO"},
                new Noms(){Key = 10, Value="MICHOACAN"}

            };
            return tiposN;
        }
        public INavigation Navigation { get; set; }
        public StackLayout ConetenedorButton { set;  get; }
        public Command PreciosdeGas { set; get; }
        public GasolineriaViewModel(StackLayout contenedor, INavigation navigation)
        {
            Navigation = navigation;
            
            Ciudades = CrearListaNoms();
            SinSeleccion = -1;

            Cliente = new HttpClient();
            Cliente.DefaultRequestHeaders.Accept.Clear();
            Cliente.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue
                ("application/Json"));

            ConetenedorButton = contenedor;
            PreciosdeGas = new Command(GasolineraE);
            Tipos = CrearListaTipos().OrderBy(t => t.Value).ToList();
            SinSeleccion2 = -1;
        }

        public GasolineriaViewModel()
        {
           
        }

        public string link;
        public string link2;
        public async void GasolineraE()
        {
            int statis = 0;
            int static2 = 0;
            if (_sinseleccion != -1)
            {
                statis = Validar();
                if (statis == 0)
                {
                    switch (_seleccionCiudad.Key)
                    {
                        case 1:
                            link = URIGaso + ";=PUE";
                            break;
                        case 2:
                            link = URIGaso + ";=VER";
                            break;
                        case 3:
                            link = URIGaso + ";=SON";
                            break;
                        case 4:
                            link = URIGaso + ";=CHIS";
                            break;
                        case 5:
                            link = URIGaso + ";=YUC";
                            break;
                        case 6:
                            link = URIGaso + ";=JAL";
                            break;
                        case 7:
                            link = URIGaso + ";=MOR";
                            break;
                        case 8:
                            link = URIGaso + ";=NAY";
                            break;
                        case 9:
                            link = URIGaso + ";=DGO";
                            break;
                        case 10:
                            link = URIGaso + ";=MICH";
                            break;
                    }

                }
                else await Application.Current.MainPage.DisplayAlert("Aviso", "Selecciona un Estado", "OK");
            }

            if (_sinseleccion2 != -1)
            {
                static2 = Validar();
                if (static2 == 0)
                {
                    if (_seleccionCiudad.Key != 0)
                    {
                        switch (_seleccionTGas.Key)
                        {
                            case 1:
                                link2 = link + "&tipo;=REG";
                                break;
                            case 2:
                                link2 = link + "&tipo;=PRE";
                                break;
                            case 3:
                                link2 = link + "&tipo;=DIE";
                                break;
                        }
                    }
                    else await Application.Current.MainPage.DisplayAlert("Aviso", "Selecciona un Estado", "OK");
                }
            }
        }
        public string msj;
        public int Validar()
        {
            string estado;
            int status = 0;

            foreach (View oview in ConetenedorButton.Children)
            {
                if (oview.ClassId != null && oview.ClassId.Contains("Validar"))
                {
                    estado = oview.GetType().Name;
                    if (estado.Equals("Picker"))
                    {
                        if ((((Picker)oview).SelectedIndex == 0))
                        {
                            msj = "Debe de Seleccinar un Estado o Tipo de Gasolina";
                            status = 1;
                            return status;
                        }
                        else
                        {
                            try
                            {
                                double x = Convert.ToDouble(((Picker)oview).SelectedIndex);
                                if (x < 0) status = 2;
                            }
                            catch (FormatException)
                            {
                                status = 3;
                                return status;
                            }
                        }
                    }
                }
            }
            return status;
        }
    }
}
